<!DOCTYPE html>
<html>
  
<head>
    <title>
        Receipt
    </title>
</head>
<body>
<style>
  .bordered {
    width: 1350px;
    height: 650px;
    padding: 20px;
    border: 20px ridge black;
  }
</style>
 <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3
.1/css/bootstrap.min.css" integrity="sha384-
ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="an
onymous">
<style type="text/css">
  		#side_bar{
  			background-color: whitesmoke;
  			padding: 50px;
  			width: 300px;
  			height: 450px;
  		}
  	</style>
<style>
    h2 {text-align: center;}
    h1 {text-align: center;}
    p {text-align: center;}
    h3 {text-align: Right;}
</style>
</head>
<body>
    <div class="bordered">
        <div class="card-body">
        <h2 style="background-color:DodgerBlue;">***************</p>
        <h2 style="background-color:DodgerBlue;">Patient History</h2>
        <p style="background-color:DodgerBlue;">***************</p>
        <h3 style="color:blue;">7 January, 2021</h3>
        <div class="row">
            <div class="col-md-2"></div>
                <div class="col-md-4">
                    <h4 style="color:blue;">First Name:</h4>
                    <h4 style="color:blue;">Last Name:</h4>
                    <h4 style="color:blue;">Gender:</h4>
                    <h4 style="color:blue;">Phone No:</h4>
                    <h4 style="color:blue;">Address:</h4>
                    <h4 style="color:blue;">Disease:</h4>  <!--sergical gyna heart Emergency--> 
                    <h4 style="color:blue;">Discription:</h4>
                    <h4 style="color:blue;">Daily Dose:</h4> 
                    <h4 style="color:blue;">Company:</h4> 
                </div>
            <div class="col-md-5">
                    <h4 style="color:blue;">Ibrar</h4>
                    <h4 style="color:blue;">Babar  </h4>
                    <h4 style="color:blue;">Male  </h4>
                    <h4 style="color:blue;">13364  </h4>
                    <h4 style="color:blue;">Alraheem Garden  </h4>
                    <h4 style="color:blue;">Emergency </h4>  <!--sergical gyna heart Emergency--> 
                    <h4 style="color:blue;">Apply the given cream for one Month  </h4>
                    <h4 style="color:blue;">2</h4> 
                    <h4 style="color:blue;">NULL</h4> 
            </div>
        </div>  
            
            <h2 style="background-color:DodgerBlue;">***************</h2>
        </div>

</body>
</html>