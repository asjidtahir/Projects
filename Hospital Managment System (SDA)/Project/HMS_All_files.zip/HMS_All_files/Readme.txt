software required-----    	1)wamp   2) visual Studio Code or any other software which one suits you. 
First unzip the folder (HMS_ALL_files).
Simply open HMS folder.
Run lms.sql file on wamp.
copy the HMS folder into your wamp server directory (www) and paste HMS Folder in www directory.
Now open the LMS folder through visual studio code.
And run using (http://localhost/hms/index.php)
